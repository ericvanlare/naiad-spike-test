import type { ExtensionAPI } from "@mariozechner/pi-coding-agent";
import {
  type AssistantMessage,
  type AssistantMessageEventStream,
  type Context,
  type Model,
  type SimpleStreamOptions,
  createAssistantMessageEventStream,
} from "@mariozechner/pi-ai";

export default function (pi: ExtensionAPI) {
  const inferenceUrl = process.env.NAIAD_INFERENCE_URL;
  const apiKey = process.env.NAIAD_API_KEY ?? "";
  const model = process.env.NAIAD_MODEL ?? "llama-3.1-8b";
  const threadId = process.env.NAIAD_THREAD_ID ?? "";
  const sessionId = process.env.NAIAD_SESSION_ID ?? "";

  if (!inferenceUrl) {
    console.error("[naiad-extension] NAIAD_INFERENCE_URL not set, skipping provider registration");
    return;
  }

  // Event forwarding via HTTP callback (for interactive mode)
  const callbackUrl = process.env.NAIAD_CALLBACK_URL;
  if (callbackUrl && typeof (pi as any).on === "function") {
    const postEvent = (type: string, data: unknown) => {
      fetch(callbackUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type, data }),
      }).catch(() => {
        // Best effort — don't crash the agent if callback fails
      });
    };

    (pi as any).on("agent_start", (event: unknown) => postEvent("agent_start", event));
    (pi as any).on("agent_end", (event: unknown) => postEvent("agent_end", event));
    (pi as any).on("turn_start", (event: unknown) => postEvent("turn_start", event));
    (pi as any).on("turn_end", (event: unknown) => postEvent("turn_end", event));
    (pi as any).on("message_start", (event: unknown) => postEvent("message_start", event));
    (pi as any).on("message_end", (event: unknown) => postEvent("message_end", event));
    (pi as any).on("message_update", (event: unknown) => postEvent("message_update", event));
    (pi as any).on("tool_execution_start", (event: unknown) => postEvent("tool_execution_start", event));
    (pi as any).on("tool_execution_end", (event: unknown) => postEvent("tool_execution_end", event));
  }

  pi.registerProvider("naiad-proxy", {
    baseUrl: inferenceUrl,
    apiKey: "NAIAD_API_KEY",
    api: "naiad-openai",
    models: [
      {
        id: model,
        name: `Naiad Model (${model})`,
        input: ["text"],
        cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
        contextWindow: 131072,
        maxTokens: 8192,
      },
    ],
    streamSimple: streamNaiad,
  });

  function streamNaiad(
    mdl: Model,
    context: Context,
    options?: SimpleStreamOptions,
  ): AssistantMessageEventStream {
    const stream = createAssistantMessageEventStream();

    (async () => {
      const output: AssistantMessage = {
        role: "assistant",
        content: [],
        api: mdl.api,
        provider: mdl.provider,
        model: mdl.id,
        usage: {
          input: 0,
          output: 0,
          cacheRead: 0,
          cacheWrite: 0,
          totalTokens: 0,
          cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 },
        },
        stopReason: "stop",
        timestamp: Date.now(),
      };

      try {
        // Build messages for OpenAI chat completions format
        const messages = context.messages.map((msg) => {
          if (msg.role === "user") {
            const content =
              typeof msg.content === "string"
                ? msg.content
                : msg.content
                    .filter((c): c is { type: "text"; text: string } => c.type === "text")
                    .map((c) => c.text)
                    .join("\n");
            return { role: "user" as const, content };
          }
          if (msg.role === "assistant") {
            const text = msg.content
              .filter((c): c is { type: "text"; text: string } => c.type === "text")
              .map((c) => c.text)
              .join("");
            return { role: "assistant" as const, content: text };
          }
          return { role: "user" as const, content: "(tool result)" };
        });

        if (context.systemPrompt) {
          messages.unshift({ role: "user", content: `[System] ${context.systemPrompt}` });
        }

        const res = await fetch(`${inferenceUrl}/v1/chat/completions`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`,
            "X-Naiad-Thread-Id": threadId,
            "X-Naiad-Session-Id": sessionId,
          },
          body: JSON.stringify({
            model: mdl.id,
            messages,
            stream: true,
            stream_options: { include_usage: true },
          }),
          signal: options?.signal,
        });

        if (!res.ok) {
          throw new Error(`Inference proxy error: ${res.status} ${await res.text()}`);
        }

        output.content.push({ type: "text", text: "" });
        stream.push({ type: "start", partial: output });
        stream.push({ type: "text_start", contentIndex: 0, partial: output });

        const reader = res.body!.getReader();
        const decoder = new TextDecoder();
        let buffer = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });

          const lines = buffer.split("\n");
          buffer = lines.pop() ?? "";

          for (const line of lines) {
            if (!line.startsWith("data: ") || line === "data: [DONE]") continue;
            try {
              const chunk = JSON.parse(line.slice(6));

              if (chunk.usage) {
                output.usage.input = chunk.usage.prompt_tokens ?? 0;
                output.usage.output = chunk.usage.completion_tokens ?? 0;
                output.usage.totalTokens = chunk.usage.total_tokens ?? 0;
              }

              const choice = chunk.choices?.[0];
              if (!choice) continue;

              if (choice.finish_reason === "stop") {
                output.stopReason = "stop";
              }

              const delta = choice.delta?.content;
              if (delta) {
                (output.content[0] as { type: "text"; text: string }).text += delta;
                stream.push({ type: "text_delta", contentIndex: 0, delta, partial: output });
              }
            } catch {
              // skip unparseable lines
            }
          }
        }

        stream.push({
          type: "text_end",
          contentIndex: 0,
          content: (output.content[0] as { type: "text"; text: string }).text,
          partial: output,
        });
        stream.push({ type: "done", reason: output.stopReason as "stop" | "length" | "toolUse", message: output });
        stream.end();
      } catch (error) {
        output.stopReason = options?.signal?.aborted ? "aborted" : "error";
        output.errorMessage = error instanceof Error ? error.message : String(error);
        stream.push({ type: "error", reason: output.stopReason, error: output });
        stream.end();
      }
    })();

    return stream;
  }
}

import type { ExtensionAPI } from "@mariozechner/pi-coding-agent";
import {
  type AssistantMessage,
  type AssistantMessageEventStream,
  type Context,
  type Model,
  type SimpleStreamOptions,
  type ToolCall,
  createAssistantMessageEventStream,
} from "@mariozechner/pi-ai";

export default function (pi: ExtensionAPI) {
  const inferenceUrl = process.env.NAIAD_INFERENCE_URL;
  const apiKey = process.env.NAIAD_API_KEY ?? "";
  const model = process.env.NAIAD_MODEL ?? "llama-3.1-8b";
  const threadId = process.env.NAIAD_THREAD_ID ?? "";
  const sessionId = process.env.NAIAD_SESSION_ID ?? "";

  if (!inferenceUrl) {
    console.error("[naiad-extension] NAIAD_INFERENCE_URL not set, skipping provider registration");
    return;
  }

  // Event forwarding via HTTP callback (for interactive mode)
  const callbackUrl = process.env.NAIAD_CALLBACK_URL;
  if (callbackUrl && typeof (pi as any).on === "function") {
    const postEvent = (type: string, data: unknown) => {
      fetch(callbackUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type, data }),
      }).catch(() => {
        // Best effort — don't crash the agent if callback fails
      });
    };

    (pi as any).on("agent_start", (event: unknown) => postEvent("agent_start", event));
    (pi as any).on("agent_end", (event: unknown) => postEvent("agent_end", event));
    (pi as any).on("turn_start", (event: unknown) => postEvent("turn_start", event));
    (pi as any).on("turn_end", (event: unknown) => postEvent("turn_end", event));
    (pi as any).on("message_start", (event: unknown) => postEvent("message_start", event));
    (pi as any).on("message_end", (event: unknown) => postEvent("message_end", event));
    (pi as any).on("message_update", (event: unknown) => postEvent("message_update", event));
    (pi as any).on("tool_execution_start", (event: unknown) => postEvent("tool_execution_start", event));
    (pi as any).on("tool_execution_end", (event: unknown) => postEvent("tool_execution_end", event));
  }

  pi.registerProvider("naiad-proxy", {
    baseUrl: inferenceUrl,
    apiKey: "NAIAD_API_KEY",
    api: "naiad-openai",
    models: [
      {
        id: model,
        name: `Naiad Model (${model})`,
        input: ["text"],
        cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
        contextWindow: 131072,
        maxTokens: 8192,
      },
    ],
    streamSimple: streamNaiad,
  });

  function convertMessages(context: Context): any[] {
    const messages: any[] = [];

    if (context.systemPrompt) {
      messages.push({ role: "system", content: context.systemPrompt });
    }

    for (const msg of context.messages) {
      if (msg.role === "user") {
        const content =
          typeof msg.content === "string"
            ? msg.content
            : msg.content
                .filter((c): c is { type: "text"; text: string } => c.type === "text")
                .map((c) => c.text)
                .join("\n");
        messages.push({ role: "user" as const, content });
      } else if (msg.role === "assistant") {
        const assistantMsg: any = { role: "assistant", content: null };

        const textBlocks = msg.content.filter((b): b is { type: "text"; text: string } => b.type === "text");
        if (textBlocks.length > 0) {
          assistantMsg.content = textBlocks.map((b) => b.text).join("");
        }

        const toolCalls = msg.content.filter((b): b is ToolCall => b.type === "toolCall");
        if (toolCalls.length > 0) {
          assistantMsg.tool_calls = toolCalls.map((tc) => ({
            id: tc.id,
            type: "function",
            function: {
              name: tc.name,
              arguments: JSON.stringify(tc.arguments),
            },
          }));
        }

        // Skip empty assistant messages
        if (assistantMsg.content === null && !assistantMsg.tool_calls) continue;
        messages.push(assistantMsg);
      } else if (msg.role === "toolResult") {
        const textResult = msg.content
          .filter((c): c is { type: "text"; text: string } => c.type === "text")
          .map((c) => c.text)
          .join("\n");
        messages.push({
          role: "tool",
          tool_call_id: msg.toolCallId,
          content: textResult || "(no output)",
        });
      }
    }

    return messages;
  }

  function convertTools(context: Context): any[] | undefined {
    if (!context.tools || context.tools.length === 0) return undefined;
    return context.tools.map((tool) => ({
      type: "function",
      function: {
        name: tool.name,
        description: tool.description,
        parameters: tool.parameters,
      },
    }));
  }

  function streamNaiad(
    mdl: Model,
    context: Context,
    options?: SimpleStreamOptions,
  ): AssistantMessageEventStream {
    const stream = createAssistantMessageEventStream();

    (async () => {
      const output: AssistantMessage = {
        role: "assistant",
        content: [],
        api: mdl.api,
        provider: mdl.provider,
        model: mdl.id,
        usage: {
          input: 0,
          output: 0,
          cacheRead: 0,
          cacheWrite: 0,
          totalTokens: 0,
          cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 },
        },
        stopReason: "stop",
        timestamp: Date.now(),
      };

      try {
        const messages = convertMessages(context);
        const tools = convertTools(context);

        const body: any = {
          model: mdl.id,
          messages,
          stream: true,
          stream_options: { include_usage: true },
        };
        if (tools) {
          body.tools = tools;
        }

        const res = await fetch(`${inferenceUrl}/v1/chat/completions`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`,
            "X-Naiad-Thread-Id": threadId,
            "X-Naiad-Session-Id": sessionId,
          },
          body: JSON.stringify(body),
          signal: options?.signal,
        });

        if (!res.ok) {
          throw new Error(`Inference proxy error: ${res.status} ${await res.text()}`);
        }

        stream.push({ type: "start", partial: output });

        const reader = res.body!.getReader();
        const decoder = new TextDecoder();
        let buffer = "";

        // Track current content block for proper event sequencing
        let currentBlock: any = null;
        const blocks = output.content;
        const blockIndex = () => blocks.length - 1;

        const finishCurrentBlock = (block: any) => {
          if (!block) return;
          if (block.type === "text") {
            stream.push({
              type: "text_end",
              contentIndex: blockIndex(),
              content: block.text,
              partial: output,
            });
          } else if (block.type === "toolCall") {
            try {
              block.arguments = JSON.parse(block.partialArgs || "{}");
            } catch {
              block.arguments = {};
            }
            delete block.partialArgs;
            stream.push({
              type: "toolcall_end",
              contentIndex: blockIndex(),
              toolCall: block as ToolCall,
              partial: output,
            });
          }
        };

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });

          const lines = buffer.split("\n");
          buffer = lines.pop() ?? "";

          for (const line of lines) {
            if (!line.startsWith("data: ") || line === "data: [DONE]") continue;
            try {
              const chunk = JSON.parse(line.slice(6));

              if (chunk.usage) {
                output.usage.input = chunk.usage.prompt_tokens ?? 0;
                output.usage.output = chunk.usage.completion_tokens ?? 0;
                output.usage.totalTokens = chunk.usage.total_tokens ?? 0;
              }

              const choice = chunk.choices?.[0];
              if (!choice) continue;

              if (choice.finish_reason) {
                if (choice.finish_reason === "tool_calls" || choice.finish_reason === "function_call") {
                  output.stopReason = "toolUse";
                } else if (choice.finish_reason === "length") {
                  output.stopReason = "length";
                } else {
                  output.stopReason = "stop";
                }
              }

              // Handle text content delta
              const delta = choice.delta?.content;
              if (delta) {
                if (!currentBlock || currentBlock.type !== "text") {
                  finishCurrentBlock(currentBlock);
                  currentBlock = { type: "text", text: "" };
                  output.content.push(currentBlock);
                  stream.push({ type: "text_start", contentIndex: blockIndex(), partial: output });
                }
                currentBlock.text += delta;
                stream.push({ type: "text_delta", contentIndex: blockIndex(), delta, partial: output });
              }

              // Handle tool call deltas
              if (choice.delta?.tool_calls) {
                for (const toolCall of choice.delta.tool_calls) {
                  if (
                    !currentBlock ||
                    currentBlock.type !== "toolCall" ||
                    (toolCall.id && currentBlock.id !== toolCall.id)
                  ) {
                    finishCurrentBlock(currentBlock);
                    currentBlock = {
                      type: "toolCall",
                      id: toolCall.id || "",
                      name: toolCall.function?.name || "",
                      arguments: {},
                      partialArgs: "",
                    };
                    output.content.push(currentBlock);
                    stream.push({ type: "toolcall_start", contentIndex: blockIndex(), partial: output });
                  }
                  if (currentBlock.type === "toolCall") {
                    if (toolCall.id) currentBlock.id = toolCall.id;
                    if (toolCall.function?.name) currentBlock.name = toolCall.function.name;
                    let argDelta = "";
                    if (toolCall.function?.arguments) {
                      argDelta = toolCall.function.arguments;
                      currentBlock.partialArgs += argDelta;
                      try {
                        currentBlock.arguments = JSON.parse(currentBlock.partialArgs);
                      } catch {
                        // partial JSON, keep accumulating
                      }
                    }
                    stream.push({
                      type: "toolcall_delta",
                      contentIndex: blockIndex(),
                      delta: argDelta,
                      partial: output,
                    });
                  }
                }
              }
            } catch {
              // skip unparseable lines
            }
          }
        }

        finishCurrentBlock(currentBlock);
        stream.push({ type: "done", reason: output.stopReason as "stop" | "length" | "toolUse", message: output });
        stream.end();
      } catch (error) {
        output.stopReason = options?.signal?.aborted ? "aborted" : "error";
        output.errorMessage = error instanceof Error ? error.message : String(error);
        stream.push({ type: "error", reason: output.stopReason, error: output });
        stream.end();
      }
    })();

    return stream;
  }
}

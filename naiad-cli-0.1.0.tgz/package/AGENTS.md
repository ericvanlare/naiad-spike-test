# Naiad CLI — Agent Instructions

## Building the CLI locally

From the `mvp1/clients/cli/` directory:

```bash
npm install        # only needed if dependencies changed
npm run build      # compiles TypeScript → dist/
npm link           # makes `naiad` available on PATH
```

Verify with: `naiad --help`

## Key paths

- Entry point: `src/index.ts`
- Build output: `dist/index.js` (the `naiad` binary target)
- Pi extension: `extensions/naiad-extension.ts`

## Environment

The CLI requires these env vars at runtime:

- `NAIAD_API_KEY` — API key for the Naiad platform
- `NAIAD_API_URL` — Platform API URL (default: `http://localhost:3000`)

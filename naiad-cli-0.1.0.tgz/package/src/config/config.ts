import { readFileSync, existsSync } from "fs";
import { join } from "path";
import { homedir } from "os";

export interface NaiadConfig {
  apiUrl: string;
  apiKey: string;
}

export function loadConfig(): NaiadConfig {
  const apiUrl = process.env.NAIAD_API_URL || loadFromFile("api_url") || "http://localhost:3000";
  const apiKey = process.env.NAIAD_API_KEY || loadFromFile("api_key") || "";

  return { apiUrl, apiKey };
}

function loadFromFile(key: string): string | undefined {
  const configPath = join(homedir(), ".naiad", "config.json");
  if (!existsSync(configPath)) return undefined;
  try {
    const config = JSON.parse(readFileSync(configPath, "utf-8"));
    return config[key];
  } catch {
    return undefined;
  }
}

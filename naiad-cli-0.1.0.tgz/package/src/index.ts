#!/usr/bin/env node

import { loadConfig } from "./config/config.js";
import { execCommand } from "./commands/exec.js";
import { interactiveCommand } from "./commands/interactive.js";

const args = process.argv.slice(2);

if (args.includes("--help") || args.includes("-h")) {
  console.log(`naiad - Naiad 2.0 CLI

Usage:
  naiad [options]              Interactive mode (default)
  naiad exec [options] "<prompt>"   Headless mode

Interactive options:
  --model <model_id>       Model to use (default: first active model from server)
  --session <session_id>   Resume specific session
  -c, --continue           Continue most recent session
  --help, -h               Show this help

Exec options:
  --model <model_id>       Model to use (default: first active model from server)

Environment:
  NAIAD_API_URL            Platform API URL (default: http://localhost:3000)
  NAIAD_API_KEY            API key for authentication`);
  process.exit(0);
}

const config = loadConfig();

if (!config.apiKey) {
  console.error("Error: NAIAD_API_KEY is required. Set it via environment variable or ~/.naiad/config.json");
  process.exit(1);
}

const command = args[0];

if (command === "exec") {
  // Parse exec args
  let model: string | undefined;
  let prompt: string | undefined;

  for (let i = 1; i < args.length; i++) {
    if (args[i] === "--model" && args[i + 1]) {
      model = args[++i];
    } else if (!prompt) {
      prompt = args[i];
    }
  }

  if (!prompt) {
    console.error("Error: prompt is required. Usage: naiad exec \"<prompt>\"");
    process.exit(1);
  }

  execCommand(config, prompt, model).catch((err) => {
    console.error("Error:", err.message || err);
    process.exit(1);
  });
} else {
  // Interactive mode (default)
  let model: string | undefined;
  let sessionId: string | undefined;
  let continueRecent = false;

  for (let i = 0; i < args.length; i++) {
    if (args[i] === "--model" && args[i + 1]) {
      model = args[++i];
    } else if (args[i] === "--session" && args[i + 1]) {
      sessionId = args[++i];
    } else if (args[i] === "-c" || args[i] === "--continue") {
      continueRecent = true;
    }
  }

  interactiveCommand(config, { modelFlag: model, sessionId, continueRecent }).catch((err) => {
    console.error("Error:", err.message || err);
    process.exit(1);
  });
}

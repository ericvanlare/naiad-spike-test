import { spawn, type ChildProcess } from "child_process";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

export interface PiOptions {
  model: string;
  sessionDir: string;
  extensionPath: string;
  env: Record<string, string>;
}

export interface PiProcess {
  process: ChildProcess;
  sendPrompt: (prompt: string) => void;
  shutdown: () => Promise<void>;
  onEvent: (handler: (event: PiRpcEvent) => void) => void;
}

export interface PiRpcEvent {
  type: string;
  [key: string]: unknown;
}

export function launchPi(options: PiOptions): PiProcess {
  const piPath = resolvePiBin();

  const piProcess = spawn(piPath, [
    "--mode", "rpc",
    "--provider", "naiad-proxy",
    "--model", options.model,
    "--session-dir", options.sessionDir,
    "-e", options.extensionPath,
  ], {
    env: { ...process.env, ...options.env },
    stdio: ["pipe", "pipe", "pipe"],
  });

  let eventHandler: ((event: PiRpcEvent) => void) | null = null;
  let lineBuffer = "";

  piProcess.stdout!.on("data", (data: Buffer) => {
    lineBuffer += data.toString();
    const lines = lineBuffer.split("\n");
    lineBuffer = lines.pop() ?? "";

    for (const line of lines) {
      if (!line.trim()) continue;
      try {
        const event = JSON.parse(line) as PiRpcEvent;
        eventHandler?.(event);
      } catch {
        // Not JSON, forward as raw output
        process.stdout.write(line + "\n");
      }
    }
  });

  piProcess.stderr!.on("data", (data: Buffer) => {
    process.stderr.write(data);
  });

  return {
    process: piProcess,
    sendPrompt(prompt: string) {
      const msg = JSON.stringify({ type: "prompt", message: prompt });
      piProcess.stdin!.write(msg + "\n");
    },
    async shutdown() {
      // Close stdin (EOF) + SIGTERM per spike results
      piProcess.stdin!.end();
      await new Promise<void>((resolve) => {
        const timeout = setTimeout(() => {
          piProcess.kill("SIGKILL");
          resolve();
        }, 5000);
        piProcess.on("exit", () => {
          clearTimeout(timeout);
          resolve();
        });
        setTimeout(() => piProcess.kill("SIGTERM"), 100);
      });
    },
    onEvent(handler: (event: PiRpcEvent) => void) {
      eventHandler = handler;
    },
  };
}

export interface PiInteractiveProcess {
  process: ChildProcess;
  shutdown: () => Promise<void>;
}

export interface PiInteractiveOptions extends PiOptions {
  resumeSessionFile?: string;
}

export function launchPiInteractive(options: PiInteractiveOptions): PiInteractiveProcess {
  const piPath = resolvePiBin();

  const args = [
    "--provider", "naiad-proxy",
    "--model", options.model,
    "--session-dir", options.sessionDir,
    "-e", options.extensionPath,
  ];

  if (options.resumeSessionFile) {
    args.push("--session", options.resumeSessionFile);
  }

  const piProcess = spawn(piPath, args, {
    env: { ...process.env, ...options.env },
    stdio: "inherit",
  });

  return {
    process: piProcess,
    async shutdown() {
      await new Promise<void>((resolve) => {
        const timeout = setTimeout(() => {
          piProcess.kill("SIGKILL");
          resolve();
        }, 5000);
        piProcess.on("exit", () => {
          clearTimeout(timeout);
          resolve();
        });
        piProcess.kill("SIGTERM");
      });
    },
  };
}

function resolvePiBin(): string {
  // Try to resolve the pi binary from node_modules
  try {
    const __dirname = dirname(fileURLToPath(import.meta.url));
    const piCli = join(__dirname, "..", "..", "node_modules", ".bin", "pi");
    return piCli;
  } catch {
    return "pi"; // Fall back to PATH
  }
}

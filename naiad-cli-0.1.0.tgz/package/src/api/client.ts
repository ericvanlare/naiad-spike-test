import type { NaiadConfig } from "../config/config.js";

export class APIClient {
  private baseUrl: string;
  private apiKey: string;

  constructor(config: NaiadConfig) {
    this.baseUrl = config.apiUrl;
    this.apiKey = config.apiKey;
  }

  private async request(method: string, path: string, body?: unknown): Promise<Response> {
    const url = `${this.baseUrl}${path}`;
    const res = await fetch(url, {
      method,
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${this.apiKey}`,
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    return res;
  }

  async listModels(): Promise<{ models: Array<{ id: string; display_name: string }> }> {
    const res = await this.request("GET", "/api/v1/models");
    if (!res.ok) throw new Error(`Failed to list models: ${res.status} ${await res.text()}`);
    return res.json() as Promise<{ models: Array<{ id: string; display_name: string }> }>;
  }

  async createThread(prompt: string, title?: string): Promise<{ id: string; status: string }> {
    const res = await this.request("POST", "/api/v1/threads", {
      prompt,
      title,
      source: "cli",
      trigger: "cli",
    });
    if (!res.ok) throw new Error(`Failed to create thread: ${res.status} ${await res.text()}`);
    return res.json() as Promise<{ id: string; status: string }>;
  }

  async updateThread(threadId: string, update: { status?: string; error?: string }): Promise<{ id: string; status: string }> {
    const res = await this.request("PATCH", `/api/v1/threads/${threadId}`, update);
    if (!res.ok) throw new Error(`Failed to update thread: ${res.status} ${await res.text()}`);
    return res.json() as Promise<{ id: string; status: string }>;
  }

  async createSession(threadId: string, agentId: string): Promise<{ id: string }> {
    const res = await this.request("POST", `/api/v1/threads/${threadId}/sessions`, {
      runtime: "local_cli",
      agent_id: agentId,
    });
    if (!res.ok) throw new Error(`Failed to create session: ${res.status} ${await res.text()}`);
    return res.json() as Promise<{ id: string }>;
  }

  async updateSession(sessionId: string, status: string): Promise<void> {
    const res = await this.request("PATCH", `/api/v1/sessions/${sessionId}`, { status });
    if (!res.ok) throw new Error(`Failed to update session: ${res.status} ${await res.text()}`);
  }

  async postEvents(threadId: string, sessionId: string, events: Array<{ client_seq: number; event_type: string; data: unknown }>): Promise<{ accepted: number; duplicates: number }> {
    const res = await this.request("POST", `/api/v1/threads/${threadId}/events`, {
      session_id: sessionId,
      events,
    });
    if (!res.ok) throw new Error(`Failed to post events: ${res.status} ${await res.text()}`);
    return res.json() as Promise<{ accepted: number; duplicates: number }>;
  }

  async postHeartbeat(agentId: string, threadId: string, sessionId: string, status: string, metrics: Record<string, unknown> = {}): Promise<void> {
    const res = await this.request("POST", "/api/v1/agents/heartbeat", {
      agent_id: agentId,
      thread_id: threadId,
      session_id: sessionId,
      status,
      metrics,
    });
    if (!res.ok) throw new Error(`Failed to post heartbeat: ${res.status} ${await res.text()}`);
  }

  async getUploadUrls(sessionId: string, chunks: Array<{ start: number; end: number; sha256_hex: string }>): Promise<{ urls: Array<{ start: number; end: number; url: string }> }> {
    const res = await this.request("POST", `/api/v1/sessions/${sessionId}/upload-urls`, { chunks });
    if (!res.ok) throw new Error(`Failed to get upload urls: ${res.status} ${await res.text()}`);
    return res.json() as Promise<{ urls: Array<{ start: number; end: number; url: string }> }>;
  }

  async finalizeSession(sessionId: string, totalBytes: number, chunkCount: number, sha256: string): Promise<void> {
    const res = await this.request("POST", `/api/v1/sessions/${sessionId}/finalize`, {
      total_bytes: totalBytes,
      chunk_count: chunkCount,
      sha256,
    });
    if (!res.ok) throw new Error(`Failed to finalize session: ${res.status} ${await res.text()}`);
  }

  async getSession(sessionId: string): Promise<{ id: string; thread_id: string; attempt: number; status: string }> {
    const res = await this.request("GET", `/api/v1/sessions/${sessionId}`);
    if (!res.ok) throw new Error(`Failed to get session: ${res.status} ${await res.text()}`);
    return res.json() as Promise<{ id: string; thread_id: string; attempt: number; status: string }>;
  }

  async listThreadSessions(threadId: string): Promise<Array<{ id: string; thread_id: string; attempt: number; status: string; started_at: string }>> {
    const res = await this.request("GET", `/api/v1/threads/${threadId}/sessions`);
    if (!res.ok) throw new Error(`Failed to list sessions: ${res.status} ${await res.text()}`);
    const data = await res.json() as { sessions: Array<{ id: string; thread_id: string; attempt: number; status: string; started_at: string }> };
    return data.sessions;
  }

  async downloadSession(sessionId: string): Promise<Buffer> {
    const res = await this.request("GET", `/api/v1/sessions/${sessionId}/download`);
    if (!res.ok) throw new Error(`Failed to download session: ${res.status} ${await res.text()}`);
    return Buffer.from(await res.arrayBuffer());
  }

  async listThreads(params?: { status?: string; limit?: number; offset?: number }): Promise<{ threads: Array<{ id: string; status: string; created_at: string }>; total: number }> {
    const searchParams = new URLSearchParams();
    if (params?.status) searchParams.set("status", params.status);
    if (params?.limit) searchParams.set("limit", String(params.limit));
    if (params?.offset) searchParams.set("offset", String(params.offset));
    const qs = searchParams.toString();
    const res = await this.request("GET", `/api/v1/threads${qs ? `?${qs}` : ""}`);
    if (!res.ok) throw new Error(`Failed to list threads: ${res.status} ${await res.text()}`);
    return res.json() as Promise<{ threads: Array<{ id: string; status: string; created_at: string }>; total: number }>;
  }
}

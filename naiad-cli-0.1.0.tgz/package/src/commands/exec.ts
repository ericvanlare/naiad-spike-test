import type { NaiadConfig } from "../config/config.js";
import { launchPi, type PiRpcEvent } from "../pi/launcher.js";
import { setupLifecycle } from "../lifecycle/setup.js";
import { startWorkers } from "../lifecycle/workers.js";
import { teardownLifecycle } from "../lifecycle/teardown.js";

export async function execCommand(config: NaiadConfig, prompt: string, modelFlag?: string) {
  const ctx = await setupLifecycle({
    config,
    modelFlag,
    threadPrompt: prompt,
  });

  // Launch pi in RPC mode
  const pi = launchPi({
    model: ctx.model,
    sessionDir: ctx.sessionDir,
    extensionPath: ctx.extensionPath,
    env: {
      NAIAD_INFERENCE_URL: `${config.apiUrl}/api/v1/inference`,
      NAIAD_API_KEY: config.apiKey,
      NAIAD_THREAD_ID: ctx.threadId,
      NAIAD_SESSION_ID: ctx.sessionId,
      NAIAD_MODEL: ctx.model,
    },
  });

  // Start background workers
  const workers = startWorkers(ctx);

  // Process pi events
  let agentEnded = false;

  pi.onEvent((event: PiRpcEvent) => {
    // Forward all events to the spool
    workers.eventSpool.pushEvent(event.type, event);

    // Print assistant message content to stdout
    if (event.type === "message_update") {
      const assistantEvent = (event as Record<string, unknown>).assistantMessageEvent as Record<string, unknown> | undefined;
      if (assistantEvent?.type === "text_delta") {
        process.stdout.write((assistantEvent.delta as string) ?? "");
      }
    }

    if (event.type === "agent_end") {
      agentEnded = true;
    }
  });

  // Send prompt (with a small delay for pi to initialize)
  await new Promise((resolve) => setTimeout(resolve, 500));
  pi.sendPrompt(prompt);

  // Wait for agent to finish
  const exitCode = await new Promise<number>((resolve) => {
    pi.process.on("exit", (code, signal) => {
      resolve(signal ? 1 : (code ?? 0));
    });

    // Also listen for agent_end to trigger shutdown
    const checkInterval = setInterval(() => {
      if (agentEnded) {
        clearInterval(checkInterval);
        pi.shutdown().then(() => {
          // process exit event will resolve the promise
        });
      }
    }, 100);
  });

  // Flush and finalize
  process.stdout.write("\n");
  console.error("[naiad] Agent finished, flushing...");

  await workers.stop();
  await teardownLifecycle({ ctx, exitCode });

  process.exit(exitCode);
}

import { mkdtempSync, writeFileSync } from "fs";
import { join, dirname } from "path";
import { tmpdir } from "os";
import { randomUUID } from "crypto";
import { fileURLToPath } from "url";

import type { NaiadConfig } from "../config/config.js";
import { APIClient } from "../api/client.js";
import { launchPiInteractive } from "../pi/launcher.js";
import { startCallbackServer } from "../callback/server.js";
import { startWorkers } from "../lifecycle/workers.js";
import { teardownLifecycle } from "../lifecycle/teardown.js";
import type { LifecycleContext } from "../lifecycle/types.js";

const __dirname = dirname(fileURLToPath(import.meta.url));

export async function interactiveCommand(
  config: NaiadConfig,
  options: { modelFlag?: string; sessionId?: string; continueRecent?: boolean },
) {
  const client = new APIClient(config);

  // Validate API key by listing models
  console.error("[naiad] Validating API key...");
  const { models } = await client.listModels();
  if (models.length === 0) {
    console.error("[naiad] No models available");
    process.exit(1);
  }
  const model = options.modelFlag || models[0].id;
  console.error(`[naiad] Using model: ${model}`);

  const sessionDir = mkdtempSync(join(tmpdir(), "naiad-session-"));
  const extensionPath = join(__dirname, "..", "..", "extensions", "naiad-extension.ts");
  const agentId = randomUUID();

  let threadId: string;
  let sessionId: string;
  let resumeSessionFile: string | undefined;

  if (options.sessionId || options.continueRecent) {
    // Resume flow
    const resolved = await resolveResumeSession(client, options);
    threadId = resolved.threadId;

    // Download previous session JSONL
    console.error(`[naiad] Downloading session ${resolved.previousSessionId}...`);
    const jsonlData = await client.downloadSession(resolved.previousSessionId);
    const jsonlFilename = `${new Date().toISOString().replace(/[:.]/g, "-")}_${randomUUID()}.jsonl`;
    resumeSessionFile = join(sessionDir, jsonlFilename);
    writeFileSync(resumeSessionFile, jsonlData);
    console.error(`[naiad] Session data written to ${resumeSessionFile}`);

    // Create new session on existing thread
    const session = await client.createSession(threadId, agentId);
    sessionId = session.id;
    console.error(`[naiad] Created session: ${sessionId} (resuming thread ${threadId})`);

    // Transition thread back to RUNNING
    await client.updateThread(threadId, { status: "RUNNING" });
  } else {
    // New session flow
    const thread = await client.createThread("[interactive session]");
    threadId = thread.id;
    console.error(`[naiad] Created thread: ${threadId}`);

    const session = await client.createSession(threadId, agentId);
    sessionId = session.id;
    console.error(`[naiad] Created session: ${sessionId}`);

    await client.updateThread(threadId, { status: "RUNNING" });
  }

  const ctx: LifecycleContext = {
    config,
    client,
    model,
    agentId,
    threadId,
    sessionId,
    sessionDir,
    extensionPath,
  };

  // Start callback server
  const callbackServer = await startCallbackServer();
  console.error(`[naiad] Callback server listening at ${callbackServer.url}`);

  // Guard against EIO on inherited stdin after pi exits and releases the PTY
  process.stdin.on("error", () => {});

  // Launch pi in interactive mode
  const pi = launchPiInteractive({
    model,
    sessionDir,
    extensionPath,
    resumeSessionFile,
    env: {
      NAIAD_INFERENCE_URL: `${config.apiUrl}/api/v1/inference`,
      NAIAD_API_KEY: config.apiKey,
      NAIAD_THREAD_ID: threadId,
      NAIAD_SESSION_ID: sessionId,
      NAIAD_MODEL: model,
      NAIAD_CALLBACK_URL: callbackServer.url,
    },
  });

  // Start background workers
  const workers = startWorkers(ctx);

  // Event pump: drain callback buffer → event spool
  const eventPump = setInterval(() => {
    const events = callbackServer.drain();
    for (const ev of events) {
      workers.eventSpool.pushEvent(ev.type, ev.data);
    }
  }, 200);

  // Wait for pi to exit
  const exitCode = await new Promise<number>((resolve) => {
    pi.process.on("exit", (code, signal) => {
      resolve(signal ? 1 : (code ?? 0));
    });
  });

  // Clean up event pump
  clearInterval(eventPump);

  // Drain any remaining callback events
  const remaining = callbackServer.drain();
  for (const ev of remaining) {
    workers.eventSpool.pushEvent(ev.type, ev.data);
  }

  console.error("[naiad] Pi exited, flushing...");

  // Stop workers and callback server
  await workers.stop();
  await callbackServer.close();

  // Teardown
  await teardownLifecycle({ ctx, exitCode });
  process.exit(exitCode);
}

async function resolveResumeSession(
  client: APIClient,
  options: { sessionId?: string; continueRecent?: boolean },
): Promise<{ threadId: string; previousSessionId: string }> {
  if (options.sessionId) {
    const session = await client.getSession(options.sessionId);
    return { threadId: session.thread_id, previousSessionId: session.id };
  }

  // -c: find most recent thread, then its most recent session
  const { threads } = await client.listThreads({ limit: 1 });
  if (threads.length === 0) {
    console.error("[naiad] No previous sessions found. Run `naiad` first to create a session.");
    process.exit(1);
  }

  const thread = threads[0];
  const sessions = await client.listThreadSessions(thread.id);
  if (sessions.length === 0) {
    console.error(`[naiad] Thread ${thread.id} has no sessions. Run \`naiad\` first to create a session.`);
    process.exit(1);
  }

  console.error(`[naiad] Continuing thread ${thread.id}, session ${sessions[0].id}`);
  return { threadId: thread.id, previousSessionId: sessions[0].id };
}

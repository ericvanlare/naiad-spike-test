import { mkdtempSync } from "fs";
import { join, dirname } from "path";
import { tmpdir } from "os";
import { randomUUID } from "crypto";
import { fileURLToPath } from "url";

import type { NaiadConfig } from "../config/config.js";
import { APIClient } from "../api/client.js";
import type { LifecycleContext } from "./types.js";

const __dirname = dirname(fileURLToPath(import.meta.url));

export async function setupLifecycle(params: {
  config: NaiadConfig;
  modelFlag?: string;
  threadPrompt: string;
}): Promise<LifecycleContext> {
  const { config, modelFlag, threadPrompt } = params;
  const client = new APIClient(config);

  // Validate API key by listing models
  console.error("[naiad] Validating API key...");
  const { models } = await client.listModels();
  if (models.length === 0) {
    throw new Error("No models available");
  }

  const model = modelFlag || models[0].id;
  console.error(`[naiad] Using model: ${model}`);

  // Create thread
  const thread = await client.createThread(threadPrompt);
  console.error(`[naiad] Created thread: ${thread.id}`);

  // Create session
  const agentId = randomUUID();
  const session = await client.createSession(thread.id, agentId);
  console.error(`[naiad] Created session: ${session.id}`);

  // Transition to RUNNING
  await client.updateThread(thread.id, { status: "RUNNING" });

  // Set up session dir
  const sessionDir = mkdtempSync(join(tmpdir(), "naiad-session-"));

  // Resolve extension path
  const extensionPath = join(__dirname, "..", "..", "extensions", "naiad-extension.ts");

  return {
    config,
    client,
    model,
    agentId,
    threadId: thread.id,
    sessionId: session.id,
    sessionDir,
    extensionPath,
  };
}

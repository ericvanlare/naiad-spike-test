import type { LifecycleContext } from "./types.js";

export async function teardownLifecycle(params: {
  ctx: LifecycleContext;
  exitCode: number;
  errorMessage?: string;
}): Promise<"COMPLETED" | "FAILED"> {
  const { ctx, exitCode, errorMessage } = params;
  const finalStatus = exitCode === 0 ? "COMPLETED" : "FAILED";

  try {
    await ctx.client.updateSession(ctx.sessionId, finalStatus);
  } catch (err) {
    console.error("[naiad] Failed to update session:", err);
  }

  try {
    if (finalStatus === "FAILED") {
      await ctx.client.updateThread(ctx.threadId, {
        status: "FAILED",
        error: errorMessage || `pi exited with code ${exitCode}`,
      });
    } else {
      await ctx.client.updateThread(ctx.threadId, { status: "COMPLETED" });
    }
  } catch (err: unknown) {
    // Treat 409 as non-fatal (thread may already be in target state)
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes("409")) {
      console.error("[naiad] Thread status already set (409), continuing");
    } else {
      console.error("[naiad] Failed to update thread:", err);
    }
  }

  console.error(`[naiad] Thread ${ctx.threadId}: ${finalStatus}`);
  return finalStatus;
}

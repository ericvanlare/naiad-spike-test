import type { NaiadConfig } from "../config/config.js";
import type { APIClient } from "../api/client.js";
import type { EventSpool } from "../sync/events.js";
import type { SessionUploader } from "../sync/session-upload.js";
import type { HeartbeatReporter } from "../sync/heartbeat.js";

export interface LifecycleContext {
  config: NaiadConfig;
  client: APIClient;
  model: string;
  agentId: string;
  threadId: string;
  sessionId: string;
  sessionDir: string;
  extensionPath: string;
}

export interface Workers {
  eventSpool: EventSpool;
  uploader: SessionUploader;
  heartbeat: HeartbeatReporter;
  stop(): Promise<void>;
}

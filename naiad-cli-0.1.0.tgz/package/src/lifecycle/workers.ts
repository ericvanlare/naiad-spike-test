import { EventSpool } from "../sync/events.js";
import { SessionUploader } from "../sync/session-upload.js";
import { HeartbeatReporter } from "../sync/heartbeat.js";
import type { LifecycleContext, Workers } from "./types.js";

export function startWorkers(ctx: LifecycleContext): Workers {
  const eventSpool = new EventSpool(ctx.client, ctx.threadId, ctx.sessionId);
  eventSpool.start();

  const uploader = new SessionUploader(ctx.client, ctx.sessionId, ctx.sessionDir);
  uploader.start();

  const heartbeat = new HeartbeatReporter(ctx.client, ctx.agentId, ctx.threadId, ctx.sessionId);
  heartbeat.start();

  return {
    eventSpool,
    uploader,
    heartbeat,
    async stop() {
      heartbeat.stop();
      await eventSpool.stop();
      await uploader.stop();
    },
  };
}

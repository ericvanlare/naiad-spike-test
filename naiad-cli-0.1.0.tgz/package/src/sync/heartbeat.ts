import type { APIClient } from "../api/client.js";

export class HeartbeatReporter {
  private client: APIClient;
  private agentId: string;
  private threadId: string;
  private sessionId: string;
  private timer: ReturnType<typeof setInterval> | null = null;

  constructor(client: APIClient, agentId: string, threadId: string, sessionId: string) {
    this.client = client;
    this.agentId = agentId;
    this.threadId = threadId;
    this.sessionId = sessionId;
  }

  start() {
    this.timer = setInterval(() => this.send(), 30_000);
    // Send initial heartbeat immediately
    this.send();
  }

  stop() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  private async send() {
    try {
      await this.client.postHeartbeat(this.agentId, this.threadId, this.sessionId, "working");
    } catch (err) {
      console.error("[heartbeat] Failed to send:", err);
    }
  }
}

import { readFileSync, readdirSync, statSync } from "fs";
import { join } from "path";
import { createHash } from "crypto";
import type { APIClient } from "../api/client.js";

const CHUNK_SIZE = 4 * 1024 * 1024; // 4 MiB

export class SessionUploader {
  private client: APIClient;
  private sessionId: string;
  private sessionDir: string;
  private pollTimer: ReturnType<typeof setInterval> | null = null;

  constructor(client: APIClient, sessionId: string, sessionDir: string) {
    this.client = client;
    this.sessionId = sessionId;
    this.sessionDir = sessionDir;
  }

  start() {
    this.pollTimer = setInterval(() => this.checkAndUpload(), 10_000);
  }

  async stop() {
    if (this.pollTimer) {
      clearInterval(this.pollTimer);
      this.pollTimer = null;
    }
    await this.checkAndUpload();
  }

  private async checkAndUpload() {
    try {
      const files = readdirSync(this.sessionDir).filter((f) => f.endsWith(".jsonl"));
      for (const file of files) {
        await this.uploadFile(join(this.sessionDir, file));
      }
    } catch {
      // Session dir may not exist yet
    }
  }

  private async uploadFile(filePath: string) {
    const stat = statSync(filePath);
    if (stat.size === 0) return;

    const data = readFileSync(filePath);
    const totalBytes = data.length;
    const chunkCount = Math.ceil(totalBytes / CHUNK_SIZE);
    const fileHash = createHash("sha256").update(data).digest("hex");

    // Build chunks
    const chunks: Array<{ start: number; end: number; sha256_hex: string; data: Buffer }> = [];
    for (let i = 0; i < chunkCount; i++) {
      const start = i * CHUNK_SIZE;
      const end = Math.min(start + CHUNK_SIZE, totalBytes);
      const chunkData = data.subarray(start, end);
      const chunkHash = createHash("sha256").update(chunkData).digest("hex");
      chunks.push({ start, end, sha256_hex: chunkHash, data: chunkData });
    }

    // Get presigned URLs
    const { urls } = await this.client.getUploadUrls(
      this.sessionId,
      chunks.map((c) => ({ start: c.start, end: c.end, sha256_hex: c.sha256_hex })),
    );

    // Upload chunks
    for (let i = 0; i < urls.length; i++) {
      const res = await fetch(urls[i].url, {
        method: "PUT",
        body: new Uint8Array(chunks[i].data),
      });
      if (!res.ok) {
        throw new Error(`Chunk upload failed: ${res.status}`);
      }
    }

    // Finalize
    await this.client.finalizeSession(this.sessionId, totalBytes, chunkCount, fileHash);
  }
}

import type { APIClient } from "../api/client.js";

export class EventSpool {
  private buffer: Array<{ client_seq: number; event_type: string; data: unknown }> = [];
  private nextSeq = 1;
  private flushTimer: ReturnType<typeof setInterval> | null = null;
  private threadId: string;
  private sessionId: string;
  private client: APIClient;

  constructor(client: APIClient, threadId: string, sessionId: string) {
    this.client = client;
    this.threadId = threadId;
    this.sessionId = sessionId;
  }

  start() {
    this.flushTimer = setInterval(() => this.flush(), 200);
  }

  pushEvent(eventType: string, data: unknown) {
    this.buffer.push({
      client_seq: this.nextSeq++,
      event_type: eventType,
      data,
    });
  }

  async flush() {
    if (this.buffer.length === 0) return;

    const batch = this.buffer.splice(0);
    try {
      await this.client.postEvents(this.threadId, this.sessionId, batch);
    } catch (err) {
      // Re-add events to buffer on failure
      this.buffer.unshift(...batch);
      console.error("[event-spool] Failed to send events:", err);
    }
  }

  async stop() {
    if (this.flushTimer) {
      clearInterval(this.flushTimer);
      this.flushTimer = null;
    }
    await this.flush();
  }
}

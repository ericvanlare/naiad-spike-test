import { createServer, type Server, type IncomingMessage, type ServerResponse } from "node:http";

export interface CallbackEvent {
  type: string;
  data: unknown;
  timestamp: number;
}

export interface CallbackServer {
  url: string;
  drain(): CallbackEvent[];
  close(): Promise<void>;
}

export async function startCallbackServer(): Promise<CallbackServer> {
  const events: CallbackEvent[] = [];

  const server = createServer((req: IncomingMessage, res: ServerResponse) => {
    if (req.method !== "POST" || req.url !== "/events") {
      res.writeHead(404);
      res.end();
      return;
    }

    let body = "";
    req.on("data", (chunk: Buffer) => {
      body += chunk.toString();
    });
    req.on("end", () => {
      try {
        const parsed = JSON.parse(body) as { type: string; data: unknown };
        events.push({
          type: parsed.type,
          data: parsed.data,
          timestamp: Date.now(),
        });
        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ ok: true }));
      } catch {
        res.writeHead(400, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ ok: false, error: "invalid json" }));
      }
    });
  });

  await new Promise<void>((resolve) => {
    server.listen(0, "127.0.0.1", () => resolve());
  });

  const addr = server.address() as { port: number };
  const url = `http://127.0.0.1:${addr.port}/events`;

  return {
    url,
    drain(): CallbackEvent[] {
      return events.splice(0);
    },
    close(): Promise<void> {
      return new Promise((resolve, reject) => {
        server.close((err) => {
          if (err) reject(err);
          else resolve();
        });
      });
    },
  };
}

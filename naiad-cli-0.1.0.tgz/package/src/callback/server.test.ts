import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { startCallbackServer } from "./server.js";

describe("CallbackServer", () => {
  it("receives a single event and drains it", async () => {
    const server = await startCallbackServer();
    try {
      const res = await fetch(server.url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "agent_start", data: { foo: 1 } }),
      });
      assert.equal(res.status, 200);

      const events = server.drain();
      assert.equal(events.length, 1);
      assert.equal(events[0].type, "agent_start");
      assert.deepEqual(events[0].data, { foo: 1 });
      assert.equal(typeof events[0].timestamp, "number");
    } finally {
      await server.close();
    }
  });

  it("buffers multiple events and drain clears them", async () => {
    const server = await startCallbackServer();
    try {
      for (let i = 0; i < 3; i++) {
        await fetch(server.url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ type: `event_${i}`, data: { i } }),
        });
      }

      const events = server.drain();
      assert.equal(events.length, 3);
      assert.equal(events[0].type, "event_0");
      assert.equal(events[1].type, "event_1");
      assert.equal(events[2].type, "event_2");

      // Drain again should be empty
      const empty = server.drain();
      assert.equal(empty.length, 0);
    } finally {
      await server.close();
    }
  });

  it("shuts down cleanly", async () => {
    const server = await startCallbackServer();
    await server.close();

    // Server should no longer accept connections
    try {
      await fetch(server.url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "test", data: {} }),
      });
      assert.fail("Should have thrown on closed server");
    } catch {
      // Expected — connection refused
    }
  });

  it("returns 400 on invalid JSON", async () => {
    const server = await startCallbackServer();
    try {
      const res = await fetch(server.url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: "not json",
      });
      assert.equal(res.status, 400);
      assert.equal(server.drain().length, 0);
    } finally {
      await server.close();
    }
  });
});
